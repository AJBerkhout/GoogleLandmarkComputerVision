Google_Landmark_Organized.ipynb contains the work done for this project
vgg16_places_365.py is third party logic for a pretrained vgg16 places model
The remained of the files are supporting documents containing class lookups for the two pretrained models used
